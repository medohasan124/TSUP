// IMPROVEMENTS
// !We need to review focus/blur system, because it is too complicated.
// Slot is not selected by key navigation. if we use appendToBody mode. It is related to the new focus/blur approach.
// Recheck performance
// list scroll overlaps border
// updateDisabled methods to avoid a remount
// create update function for the list to avoid a remount
// disable change focused element on fast scroll appendToBody
// Should we add a list direction if we use staticList prop?

// REQUESTS
// Investigate an ability to add a diff names but the same values, and check them.
